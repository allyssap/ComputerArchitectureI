/*
 * arithmetic.cpp
 *
 *  Created on: Feb. 9, 2021
 *      Author: pouli
 */
#include <stdio.h>
#include "arithmetic.h"
#define MAX 8//Byte = 8 bits

void func_not(int a[], int result[]){
	for(int i=0; i<MAX; i++){
		if(a[i] == 0){
			result[i] = 1;
		}
		else{
			result[i] = 0;
		}
	}
}
void func_2s_comp(int a[], int result[]){
	int carry = 1;
	int ones[MAX];
	func_not(a, ones);

	for(int i = (MAX-1); i>=0; i--){
		if(carry ==1 && ones[i] == 1){
			result[i] = 0;
			carry =1;
		}
		else if(carry == 1 && ones[i] ==0){
			result[i] = 1;
			carry = 0;
		}
		else{
			result[i] = ones[i];
		}
	}
}

void func_signed_mag_addition(int a[], int b[], int result[]){

	int carry=0;
	int sign, bigger;
	if(a[0] == b[0]){
		result[0] = a[0];
			///add regularly
		for(int i = MAX-1; i>=0; i--){
			result[i] = a[i] + b[i] + carry;
			if(result[i] > 1){
				carry = 1;
				result[i] %= 2;
			}
		}
		if(result[0] != a[0]){
			printf("\nOverflow Error\n");
		}
	}
	else{
		///compare larger number
		///keep sign of bigger
		for(int i=1; i<MAX; i++){
			if(a[i] > b[i]){
				sign = a[i];
				bigger = 0;
				break;
			}
			else if(b[i] > a[i]){
				sign = b[i];
				break;
				bigger = 1;
			}
		}
		///subtract smaller from bigger
		if(bigger == 0){
			//a - b
			func_signed_mag_subtraction(a,b,result);
		}
		else{
			///b-a
			func_signed_mag_subtraction(b,a,result);
		}

	}
}
void func_signed_mag_subtraction(int a[], int b[], int result[]){
	func_2s_comp(b, b);
	func_signed_mag_addition(a,b,result);
}

