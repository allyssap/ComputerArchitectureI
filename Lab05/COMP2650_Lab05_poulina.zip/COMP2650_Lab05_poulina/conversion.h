/*
 * conversion.h
 *
 *  Created on: Feb. 2, 2021
 *      Author: pouli
 */

#ifndef CONVERSION_H_
#define CONVERSION_H_


void to_octal(int a[]);
void to_decimal(int a[]);
int to_decimal_size(int a[], int size);
void to_hexadecimal(int a[]);


#endif /* CONVERSION_H_ */
