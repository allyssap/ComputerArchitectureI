/*
 * arithmetic.h
 *
 *  Created on: Feb. 9, 2021
 *      Author: pouli
 */

#ifndef ARITHMETIC_H_
#define ARITHMETIC_H_


void func_signed_mag_addition(int a[], int b[], int result[]);
void func_signed_mag_subtraction(int a[], int b[], int result[]);

#endif /* ARITHMETIC_H_ */
