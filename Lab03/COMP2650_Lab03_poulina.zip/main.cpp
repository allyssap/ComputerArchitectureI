//============================================================================
// Name        : COMP2650_Lab02_poulina.cpp
// Author      :
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================


#include <stdio.h>
#define MAX 8//Byte = 8 bits
///receives input from the user
int input(){
	int x;
	scanf(" %d", &x);
	while(x<0 || x>1){
		printf("Error.Please pick 1 or 0\n");
		scanf(" %d", &x);
	}
	return x;
}
///prints the array to the console
void printarray(int array[]){
	for(int i = 0; i<MAX; i++){
		printf("%d", array[i]);
	}
}
///if one of the numbers at the index is 0, the result at that index is 0
void func_and(int a[], int b[], int result[]){
	for(int i=0; i<MAX; i++){
		if(a[i] == 0 || b[i] == 0){
			result[i] = 0;
		}
		else{
			result[i] = 1;
		}
	}
}
///if either numbers at the same index are 1, the result at that index is 1 else the result at that index is 0
void func_or(int a[], int b[], int result[]){
	for(int i=0; i<MAX; i++){
			if(a[i] == 1 || b[i] == 1){
				result[i] = 1;
			}
			else{
				result[i] = 0;
			}
		}
}
///if 0 change to 1, if 1 change to 0
void func_not(int a[], int result[]){
	for(int i=0; i<MAX; i++){
		if(a[i] == 0){
			result[i] = 1;
		}
		else{
			result[i] = 0;
		}
	}
}
///use not function
void func_1s_comp(int a[], int result[]){
	func_not(a, result);
}
///use ones complement and add one
void func_2s_comp(int a[], int result[]){
	int carry = 1;
	int ones[MAX];
	func_1s_comp(a, ones);

	for(int i = (MAX-1); i>=0; i--){
		if(carry ==1 && ones[i] == 1){
			result[i] = 0;
			carry =1;
		}
		else if(carry == 1 && ones[i] ==0){
			result[i] = 1;
			carry = 0;
		}
		else{
			result[i] = ones[i];
		}
	}
}

///Start from the right to left until you see digit 1,then	pass it	and	NOT the digits after that. For instance, 2�s complement	of 110100 is 001100.
void func_2s_comp_star(int a[], int result[]){
	func_2s_comp(a, result);
	for(int i = (MAX-1); i>=0; i--){
		result[i] = a[i];
		if(a[i] == 1){
			i--;
			for(int n = i; n>=0; n--){
				if(a[i] == 1){
					result[i] = 0;
				}
				else{
					result[i] = 1;
				}
			}
			break;	//stop the for loop if a[i] == 1
		}
	}
}

int main(void){
	setbuf(stdout, NULL);
	int x[MAX];
	int y[MAX];
	int result[MAX];
	int command;
	///Enter the command number 0, 1, 2
	while(1){
		printf("\nEnter the command number:\n\t 0)  Exit\n\t 1)  AND\n\t 2)  OR\n\t 3)  NOT\n\t 4)  1's  Complement\n\t 5)  2's Complement\n\t 6)  2's Complement* ");
			scanf(" %d", &command);
		switch(command){
			case 0:
				printf("Exiting...");
				return 0;

			case 1:
				///AND
				printf("Enter the first binary number:");
				for(int i=0 ; i<MAX ; i++){
					printf("\nx%d= ", i);
					x[i] = input();
				}
				printf("Enter the second binary number:");
				for(int i=0 ; i<MAX ; i++){
					printf("\nx%d =", i);
					y[i] = input();
				}
				func_and(x, y, result);
				printarray(x);
				printf(" AND ");
				printarray(y);
				printf(" is ");
				printarray(result);
				break;

			case 2:
				///OR
				printf("Enter the first binary number:");
				for(int i=0 ; i<MAX ; i++){
					printf("\nx%d= ", i);
					x[i] = input();
				}
				printf("Enter the second binary number:");
				for(int i=0 ; i<MAX ; i++){
					printf("\nx%d =", i);
					y[i] = input();
				}
				func_or(x, y, result);
				printarray(x);
				printf(" OR ");
				printarray(y);
				printf(" is ");
				printarray(result);
				break;

			case 3:
				///NOT
				printf("Enter a binary number:");
				for(int i=0 ; i<MAX ; i++){
					printf("\nx%d= ", i);
					x[i] = input();
				}
				func_not(x, result);
				printf("NOT ");
				printarray(x);
				printf(" is ");
				printarray(result);
				break;

			case 4:
				///1's complement
				printf("Enter a binary number:");
				for(int i=0 ; i<MAX ; i++){
					printf("\nx%d= ", i);
					x[i] = input();
				}
				func_1s_comp(x,result);
				printf("1's Complement of ");
				printarray(x);
				printf(" is ");
				printarray(result);
				break;

			case 5:
				///2's complement
				printf("Enter a binary number:");
				for(int i=0 ; i<MAX ; i++){
					printf("\nx%d= ", i);
					x[i] = input();
				}
				func_2s_comp(x,result);
				printf("2's Complement of ");
				printarray(x);
				printf(" is ");
				printarray(result);
				break;

			case 6:
				///2's complement*
				printf("Enter a binary number:");
				for(int i=0 ; i<MAX ; i++){
					printf("\nx%d= ", i);
					x[i] = input();
				}
				func_2s_comp_star(x,result);
				printf("2's Complement* of ");
				printarray(x);
				printf(" is ");
				printarray(result);
				break;

			default:
				printf("Please pick one of the command options\n");
				break;
		}
	}
}

